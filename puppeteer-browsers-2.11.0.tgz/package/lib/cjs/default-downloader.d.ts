/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
import type { BrowserDownloader, DownloadOptions, DownloadResult } from './downloader.js';
/**
 * Default downloader implementation that uses Chrome for Testing (CfT) sources.
 * This is the standard downloader used by Puppeteer.
 *
 * @public
 */
export declare class ChromeForTestingDownloader implements BrowserDownloader {
    #private;
    constructor(baseUrl?: string);
    canDownload(options: DownloadOptions): Promise<boolean>;
    download(options: DownloadOptions, destinationPath: string): Promise<DownloadResult>;
}
//# sourceMappingURL=default-downloader.d.ts.map