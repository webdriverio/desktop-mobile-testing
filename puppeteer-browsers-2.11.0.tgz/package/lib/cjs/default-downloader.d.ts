/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
import type { BrowserDownloader, DownloadOptions } from './downloader.js';
/**
 * Default downloader implementation that uses Chrome for Testing (CfT) sources.
 * This is the standard downloader used by Puppeteer.
 *
 * @public
 */
export declare class ChromeForTestingDownloader implements BrowserDownloader {
    #private;
    constructor(baseUrl?: string);
    supports(_options: DownloadOptions): boolean;
    getDownloadUrl(options: DownloadOptions): URL;
}
//# sourceMappingURL=default-downloader.d.ts.map