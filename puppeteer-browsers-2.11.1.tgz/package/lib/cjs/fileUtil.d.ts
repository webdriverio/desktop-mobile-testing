/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @internal
 */
export declare function unpackArchive(archivePath: string, folderPath: string): Promise<void>;
/**
 * @internal
 */
export declare const internalConstantsForTesting: {
    xz: string;
    bzip2: string;
};
/**
 * Expand path template by replacing \{platform\} and \{buildId\} placeholders.
 *
 * @param template - Path template with optional placeholders
 * @param variables - Values to substitute
 * @returns Expanded path
 *
 * @internal
 */
export declare function expandPathTemplate(template: string, variables: {
    platform: string;
    buildId: string;
}): string;
//# sourceMappingURL=fileUtil.d.ts.map