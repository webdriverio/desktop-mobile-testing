/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
import type { BrowserProvider, DownloadOptions } from './provider.js';
/**
 * Default provider implementation that uses default sources.
 * This is the standard provider used by Puppeteer.
 *
 * @public
 */
export declare class DefaultProvider implements BrowserProvider {
    #private;
    constructor(baseUrl?: string);
    supports(_options: DownloadOptions): boolean;
    getDownloadUrl(options: DownloadOptions): URL;
}
//# sourceMappingURL=default-provider.d.ts.map